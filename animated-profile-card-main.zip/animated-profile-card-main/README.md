# Animated Profile Card UI Design
### This design is inspired by the work of [Online Tutorials](https://www.youtube.com/@OnlineTutorialsYT). Click [here](https://youtu.be/b2jVm6EAJt0) to watch the video.

![preview img](/preview.png)
